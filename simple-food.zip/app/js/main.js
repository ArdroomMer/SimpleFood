$(function(){

});

var mixer = mixitup(".categories__box");